#ifndef __CG_MAP_H__
#define __CG_MAP_H__

const char *cg_id_to_path(__u64 id);

#endif /* __CG_MAP_H__ */
