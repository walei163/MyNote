#!/bin/sh
#
# Start linux launcher...
#

# Load default env variables from profiles(e.g. /etc/profile.d/weston.sh)
. /etc/profile
printf "Starting launcher: "

#����ʱ�����Ϻ�ʱ��Ϊ׼
ln -snf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

CONF_DIR=/usr/local
CONF_MAC=$CONF_DIR/system.ini
CONF=$CONF_DIR/system.ini
SECTION_APP=APP_SET
SECTION_ETH=ETH_SET
SECTION_MAC=MAC_SET

INFO=`cat $CONF \
 | grep -v ^$ \
 | sed -n "s/\s\+//;/\[${SECTION_APP}\]/,/^\[/p" \
 | grep -v ^'\[' ` && eval "$INFO"


INFO=`cat $CONF \
 | grep -v ^$ \
 | sed -n "s/\s\+//;/\[${SECTION_ETH}\]/,/^\[/p" \
 | grep -v ^'\[' ` && eval "$INFO"
 
INFO=`cat $CONF_MAC \
 | grep -v ^$ \
 | sed -n "s/\s\+//;/\[${SECTION_MAC}\]/,/^\[/p" \
 | grep -v ^'\[' ` && eval "$INFO"

#export LC_ALL='zh_CN.utf8'

if [ ! -e "/usr/share/empty" ];then mkdir "/usr/share/empty";fi
echo "--------------->>> starting vsftpd <<<-----------------"                             
vsftpd &

# export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/var/run}
# export QT_QPA_PLATFORM=${QT_QPA_PLATFORM:-wayland}
# Wait for weston ready
while [ ! -e ${XDG_RUNTIME_DIR}/wayland-0 ]; do
        sleep .1
done

#init IP
ifconfig eth0 down > /dev/null
ifconfig eth1 down > /dev/null

echo Setting eth0 MAC address to $MAC_ADDR0
ifconfig eth0 hw ether $MAC_ADDR0

echo Setting eth1 MAC address to $MAC_ADDR1
ifconfig eth1 hw ether $MAC_ADDR1

ifconfig eth0 up > /dev/null
ifconfig eth1 up > /dev/null

echo Setting eth0 IP address to $IP_ADDR0, netmask to $IP_NETMASK0
ifconfig eth0 $IP_ADDR0 netmask $IP_NETMASK0

echo Setting eth1 IP address to $IP_ADDR1, netmask to $IP_NETMASK1
ifconfig eth1 $IP_ADDR1 netmask $IP_NETMASK1

cd /lib/modules/4.19.232/kernel/drivers/usb/serial
insmod ch9344.ko

#set USB0 for host mode(can connect mouse and USB Disk)
#echo host > /sys/devices/platform/usb0/dwc3_mode
cd /usr/local;
./broadcast&

cd /work/data/mglj-600/src;
echo "starting wld-app" 
F
./start_app.sh

# echo "2c7c 6005 ff" >  /sys/bus/usb-serial/drivers/option1/new_id
# sleep 1

cd /usr/local
# echo "Staring auto_pppd"
#./auto_pppd > /dev/null 2>&1 &
#./auto_pppd &
./rc.module_4g

exit 0
