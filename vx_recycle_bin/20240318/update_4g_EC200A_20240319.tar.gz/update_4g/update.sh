#!/bin/sh

ETC_DIR=/etc
UDEV_RULES_DIR=${ETC_DIR}/udev/rules.d
USER_LOCAL_DIR=/usr/local
LTE_USB_RULES=lteusb.rules

FILE_AUTO_PPPD=auto_pppd
FILE_4G_PWR_ENABLE=4g_module_enable.sh
FILE_WLD_INIT=S85wldinit.sh
FILE_4G_START_SCRIPT=rc.module_4g

echo Updating rootfs UDEV files...
cp -raf ${LTE_USB_RULES} ${UDEV_RULES_DIR}

if [ $? -ne 0 ]
then
        echo Update file: ${LTE_USB_RULES} failed.
        exit 1
fi

sleep 1

cp -raf ${FILE_AUTO_PPPD} ${USER_LOCAL_DIR}
if [ $? -ne 0 ]
then
        echo Update file: ${FILE_AUTO_PPPD} failed.
        exit 1
fi

chmod +x ${USER_LOCAL_DIR}/${FILE_AUTO_PPPD}

cp -raf ${FILE_4G_START_SCRIPT} ${USER_LOCAL_DIR}
if [ $? -ne 0 ]
then
        echo Update file: ${FILE_4G_START_SCRIPT} failed.
        exit 1
fi
chmod +x ${USER_LOCAL_DIR}/${FILE_4G_START_SCRIPT}

cp -raf ${FILE_4G_PWR_ENABLE} ${USER_LOCAL_DIR}
if [ $? -ne 0 ]
then
        echo Update file: ${FILE_4G_PWR_ENABLE} failed.
        exit 1
fi
chmod +x ${USER_LOCAL_DIR}/${FILE_4G_PWR_ENABLE}

cp -raf ${FILE_WLD_INIT} ${ETC_DIR}/init.d
if [ $? -ne 0 ]
then
        echo Update file: ${FILE_WLD_INIT} failed.
        exit 1
fi
chmod +x ${ETC_DIR}/init.d/${FILE_WLD_INIT}

sync
sleep 1

echo Updating success!
exit 0
