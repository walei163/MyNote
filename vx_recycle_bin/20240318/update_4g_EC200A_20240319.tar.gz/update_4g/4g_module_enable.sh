#!/bin/sh

GPIO3_A6_NUMBER=102
GPIO3_A7_NUMBER=103

if [ -d /sys/class/gpio/gpio${GPIO3_A7_NUMBER} ]; then
        echo out > /sys/class/gpio/gpio${GPIO3_A7_NUMBER}/direction
else
        echo ${GPIO3_A7_NUMBER} > /sys/class/gpio/export
        echo ${GPIO3_A6_NUMBER} > /sys/class/gpio/export

        echo out > /sys/class/gpio/gpio${GPIO3_A7_NUMBER}/direction

        #echo Setting GPIO3_d_A7 failed.
        #exit 1
fi

GPIO3_A7_DIR=`cat /sys/class/gpio/gpio${GPIO3_A7_NUMBER}/direction`
echo ${GPIO3_A7_DIR}

if [ "${GPIO3_A7_DIR}" = "out" ]; then
        echo 1 > /sys/class/gpio/gpio${GPIO3_A7_NUMBER}/value
        echo Setting GPIO3_d_A7 succeded!
        exit 0
else
        echo Setting GPIO3_d_A7 direction failed.
        exit 1
fi